package inventory.controller;

import inventory.service.InventoryService;

public interface Controller {
    void setService(InventoryService service);
}