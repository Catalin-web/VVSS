package pizzashop.model;

public enum PaymentType {
    Cash, Card
}